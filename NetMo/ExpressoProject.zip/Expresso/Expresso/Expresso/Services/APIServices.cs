﻿using Expresso.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;


namespace Expresso.Services
{
    public class APIServices
    {
        public async Task<List<Menu>> GetMenu()
        {
            var client = new HttpClient();
            var response = await client.GetStringAsync("https://expresso-ps.azurewebsites.net/api/Menus");
            return JsonConvert.DeserializeObject<List<Menu>>(response);
        }

        public async Task<bool> ReserveTables(Reservation reservation)
        {
            var client = new HttpClient();
            var json = JsonConvert.SerializeObject(reservation);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://expresso-ps.azurewebsites.net/api/Reservations", content);
            return response.IsSuccessStatusCode;
        }

    }
}
