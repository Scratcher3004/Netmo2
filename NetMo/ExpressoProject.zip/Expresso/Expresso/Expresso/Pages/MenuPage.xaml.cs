﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Expresso.Services;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Expresso.Pages;
using Menu = Expresso.Models.Menu;

namespace Expresso.Pages
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MenuPage : ContentPage
	{

        public ObservableCollection<Models.Menu> Menus;
        public static bool First = true;

		public MenuPage ()
		{
			InitializeComponent ();
            Menus = new ObservableCollection<Models.Menu>();
            
		}

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            if (First)
            {
                APIServices services = new APIServices();
                var menus = await services.GetMenu();
                foreach (var menu in menus)
                {
                    Menus.Add(menu);
                }
                lvMenu.ItemsSource = Menus;
                //BusyIndicator.IsRunning = false;
            }
            First = false;
        }

        private void LvMenu_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var selectedMenu = e.SelectedItem as Menu;
            if (selectedMenu != null)
            {
                Navigation.PushAsync(new SubMenuPage(selectedMenu));
            }
            ((ListView)sender).SelectedItem = null;
        }
    }

}