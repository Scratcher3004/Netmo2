﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Expresso.Pages;
using Expresso.Services;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Web;

namespace Expresso.Pages
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ReservationPage : ContentPage
	{
		public ReservationPage ()
		{
			InitializeComponent ();
		}

        private async void BtnBookTable_Clicked(object sender, EventArgs e)
        {

            Models.Reservation reservation = new Models.Reservation
            {
                Name = EntName.Text,
                Email = EntEmail.Text,
                Phone = EntPhone.Text,
                TotalPeople = EntTotalPeople.Text,
                Date = DpBookingDate.Date.ToString(),
                Time = TpBookingTime.Time.ToString()            
            };
            APIServices apiServices = new APIServices();
            bool response = await apiServices.ReserveTables(reservation);
            if (!response)
            {
                await DisplayAlert("Oops", "Something goes wrong!", "Alright");
            }
            else
            {
                await DisplayAlert("Hi", "Your table has been reserved successfully!", "Alright");
            }
        }
    }
}