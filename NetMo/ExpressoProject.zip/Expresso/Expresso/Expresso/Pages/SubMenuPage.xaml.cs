﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Expresso.Models;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.ObjectModel;
using Expresso.Pages;

namespace Expresso.Pages
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class SubMenuPage : ContentPage
	{
        public ObservableCollection<Models.SubMenu> SubMenus;
        public static bool First = true;

        public SubMenuPage (Expresso.Models.Menu menu)
		{
			InitializeComponent ();
            SubMenus = new ObservableCollection<Models.SubMenu>();
            foreach (var submenu in menu.SubMenus)
            {
                SubMenus.Add(submenu);
            }
            LvSubMenu.ItemsSource = SubMenus;
        }
	}
}